<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class templatesiteController extends Controller
{
    //template site
    public function index() {

      return view('templatesite.index');
    }
}
