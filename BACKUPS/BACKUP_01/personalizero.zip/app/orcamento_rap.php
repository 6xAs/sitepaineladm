<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orcamento_rap extends Model
{
    //
     protected $table = 'orcamento_rap';
}
