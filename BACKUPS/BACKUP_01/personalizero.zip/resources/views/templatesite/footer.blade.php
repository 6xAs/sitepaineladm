</div>

<div class="clear"></div>
</div>
</div>
</div>
<div class="footer">
<div class="footer-top">
<div class="wrap">
  <div class="section group example">
  <div class="col_1_of_2 span_1_of_2">
    <ul class="f-list">
      <li><img src="images/2.png"><span class="f-text">Atendemos todo o estado de (RO)!</span><div class="clear"></div></li>
    </ul>
  </div>
  <div class="col_1_of_2 span_1_of_2">
    <ul class="f-list">
      <li><img src="images/3.png"><span class="f-text">Celulares: (69) 9251-8735 / (69) 9268-3160 </span><div class="clear"></div></li>
    </ul>
  </div>
  <div class="clear"></div>
    </div>
</div>
</div>

<div class="footer-middle">
  <div class="wrap">

   <div class="section group example">
    <div class="col_1_of_f_1 span_1_of_f_1">
     <div class="section group example">
       <div class="col_1_of_f_2 span_1_of_f_2">
          <h3>Facebook</h3>
      <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.5";
          fjs.parentNode.insertBefore(js, fjs);
          }(document, 'script', 'facebook-jssdk'));
        </script>

        <div class="fb-page" data-href="https://www.facebook.com/personalizero/?ref=bookmarks" data-tabs="timeline" data-width="400" data-height="230" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/personalizero/?ref=bookmarks"><a href="https://www.facebook.com/personalizero/?ref=bookmarks">Personalize - Gráfica &amp; Camisaria</a></blockquote></div></div>
      </div>
      <div class="col_1_of_f_2 span_1_of_f_2">
        <h3>O que Somos!</h3>
           <div class="recent-tweet">
          <div class="recent-tweet-icon">
            <span> </span>
          </div>
          <div class="recent-tweet-info">
            <p>Somos uma Empresa especializada em personalização de ideias... </p>
          </div>
          <div class="clear"> </div>
         </div>
         <div class="recent-tweet">
          <div class="recent-tweet-icon">
            <span> </span>
          </div>
          <div class="recent-tweet-info">
            <p>Seja camisetas, cartões de visitas, panfletos, banners, convites de aniversário... e outtros
            produtos. Nós garantimos a qualidade e a exelência do produto.</p>
          </div>
          <div class="clear"> </div>
        </div>
    </div>
    <div class="clear"></div>
      </div>
   </div>
   <div class="col_1_of_f_1 span_1_of_f_1">
     <div class="section group example">
     <div class="col_1_of_f_2 span_1_of_f_2">
        <h3>Parceiros</h3>
        <ul class="f-list1">
            <li><a href="#">UP UNIFORMES </a></li>


            </ul>
     </div>
     <div class="col_1_of_f_2 span_1_of_f_2">
       <h3>Contato | Endereço</h3>
        <div class="company_address">
                      <p>José Camacho  nº3216, c/ João Pedro da Rocha</p>
                <p>- Bairro Embratel</p>
                <p>BRASIL - Porto Velho Rondônia</p>
            <p>Celular:(69) 9251-8735</p>
            <p>Celular: (69) 9268-3160</p>
          <p>Email: <span>personalize.rondonia@gmail.com</span></p>

         </div>
         <div class="social-media">
             <ul>
                <li> <span class="simptip-position-bottom simptip-movable" data-tooltip="Google"><a href="#" target="_blank"> </a></span></li>
                <li><span class="simptip-position-bottom simptip-movable" data-tooltip="Rss"><a href="#" target="_blank"> </a></span></li>
                <li><span class="simptip-position-bottom simptip-movable" data-tooltip="Facebook"><a href="#" target="_blank"> </a></span></li>
            </ul>
         </div>
    </div>
    <div class="clear"></div>
    </div>
   </div>
  <div class="clear"></div>
    </div>
  </div>
</div>
<div class="footer-bottom">
  <div class="wrap">
           <div class="copy">
          <p>Personalize ©  <?php echo date("Y"); ?>  Desenvolvido por <a href="http://sistemasloop.com" target="_blank">LOOP - Soluções em Sistemas de Informação</a></p>
         </div>
    <div class="f-list2">
     <ul>
      <li class="active"><a href="about.html">Sobre Nós</a></li> |
      <li><a href="delivery.html">Camisetas</a></li> |
      <li><a href="delivery.html">Gráfica Rápida</a></li> |
      <li><a href="contact.html">Parceiros</a></li>
      <li><a href="contact.html">Contato</a></li>
     </ul>
      </div>
      <div class="clear"></div>
      </div>
   </div>
</div>
