<div class="sidebar-bottom">
    <h2 class="m_1">Orçamento Rápido!</h2>
    <p class="m_text">A partir do orçamento nós já podemos fazer seu pedido.
    Preencha os dados e envie agora mesmo!</p>
    <div class="subscribe">
     <form>
        <label for="nome" class="title">Seu Nome:</label>
        <input name="nome" type="text" placeholder="Seu nome..." class="textbox">

        <label for="email" class="title">Email:</label>
        <input name="email" type="text" placeholder="Seu email..." class="textbox">

        <label for="celular">Celular:</label>
        <input name="celular" type="text" placeholder="Ex: (69)9999-9999" class="textbox">

        <label for="produto">Nome do produto:</label>
        <input name="produto" type="text" class="textbox" placeholder="Ex:Camiseta,banner,cartão...">

        <label for="produto">Descrição:</label>
        <div class="text">
            <input name="produto" type="text" rows="8" cols="40" class="textbox" placeholder="Decreva aqui uma prévia a respeito do que você quer">
        </div>

        <input type="submit" value="Enviar">

     </form>
    </div>
</div>
