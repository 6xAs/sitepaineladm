<div class="cont span_2_of_3">
  <h2 class="head">Nossos Produtos</h2>
<div class="top-box">
 <div class="col_1_of_3 span_1_of_3">
   <a href="single.html">
  <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/babycha/cha_bebe01.jpg" alt=""/>
    </div>
              <div class="sale-box"><span class="on_sale title_shop">Novo</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Camiseta Chá de BeBê</p>
        <div class="price1">
          <span class="actual">A partir de 5uni. R$12.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
           </a>
  </div>
   <div class="col_1_of_3 span_1_of_3">
     <a href="single.html">
    <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/convites/babycha01.jpg" alt=""/>
    </div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Convite Baby Chá Fem. 12x10</p>
        <div class="price1">
          <span class="actual">A partir de 50unid. R$69,90</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
   <a href="single.html">
    <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/arquiterua_roma_branca.jpg" alt=""/>
    </div>
              <div class="sale-box1"><span class="on_sale title_shop">Promoção</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Arquitetura Roma</p>
        <div class="price1">
          <span class="reducedfrom">$45.00</span>
          <span class="actual">A partir de 10unid. R$25.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="clear"></div>
</div>
<div class="top-box">
  <div class="col_1_of_3 span_1_of_3">
     <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/arquiterua_construct.jpg" alt=""/>
    </div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Arquitetura - Construct</p>
        <div class="price1">
          <span class="actual">A partir de 10 unid. R$25.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
    <a href="single.html">
    <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/arquitetura_orcar.jpg" alt=""/>
    </div>
     <div class="sale-box"><span class="on_sale title_shop">Novo</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Arquitetura - Oscar...</p>
        <div class="price1">
          <span class="actual">A partir de 5unid. R$25.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
   <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/adm1.jpg" alt=""/>
    </div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Lorem Ipsum simply</p>
        <div class="price1">
          <span class="actual">A partir de 5unid. R$25.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
           </a>
  </div>
  <div class="clear"></div>
</div>
<div class="top-box1">
  <div class="col_1_of_3 span_1_of_3">
     <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/adm2.jpg" alt=""/>
    </div>
               <div class="sale-box"><span class="on_sale title_shop">Nova</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Administração Black ADM</p>
        <div class="price1">
          <span class="actual">A partir de 10unid. R$25.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
   <a href="single.html">
    <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/babycha/cha_anthony01.jpg" alt=""/>
    </div>
     <div class="sale-box1"><span class="on_sale title_shop">Promoção</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Camiseta Baby Chá 100% Estampada</p>
        <div class="price1">
          <span class="reducedfrom">R$55.00</span>
          <span class="actual">A partir de 5unid. $35.00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
    <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/convites/convitecha02.jpg" alt=""/>
    </div>
               <div class="sale-box"><span class="on_sale title_shop">Novo</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Convite Baby Chá com Foto.</p>
        <div class="price1">
          <span class="actual">R$69.90 até 100unid.</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="clear"></div>
</div>
<h2 class="head">Gráfica Rápida</h2>
<div class="top-box1">
  <div class="col_1_of_3 span_1_of_3">
     <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/convites/convitecha03.jpg" alt=""/>
    </div>
               <div class="sale-box"><span class="on_sale title_shop">Novo</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Convite Baby Chá 12x10cm Masculino</p>
        <div class="price1">
          <span class="actual">Até 100unid. R$69.90</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
     <a href="single.html">
    <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/convites/niver_frozen01.jpg" alt=""/>
    </div>
      <div class="price">
       <div class="cart-left">
        <p class="title">Convite Frozen com foto</p>
        <div class="price1">
          <span class="actual">Até 50unid. R$69.90</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
   <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/convites/niver_aranha01.jpg" alt=""/>
    </div>
               <div class="sale-box"><span class="on_sale title_shop">Novo</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Convite Aniversário Homen Aranha com foto</p>
        <div class="price1">
          <span class="actual">Até 50unid. R$69.90</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="clear"></div>
</div>
    <h2 class="head">Produtos Novos</h2>
  <div class="section group">
  <div class="col_1_of_3 span_1_of_3">
     <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/sistemas_01.jpg" alt=""/>
    </div>

              <div class="price">
       <div class="cart-left">
        <p class="title">Camiseta Branca - Sistema de Informação</p>
        <div class="price1">
          <span class="actual">A partir de 5unid. R$25,00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
    <a href="single.html">
    <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/sistemas_p_internet.jpg" alt=""/>
    </div>
     <div class="sale-box"><span class="on_sale title_shop">New</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Camiseta Preta - Sistemas para Internet</p>
        <div class="price1">
          <span class="actual">A partir de 5unid. R$25,00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="col_1_of_3 span_1_of_3">
   <a href="single.html">
   <div class="inner_content clearfix">
    <div class="product_image">
      <img src="images/academicas/pedagogia01.jpg" alt=""/>
    </div>
               <div class="sale-box"><span class="on_sale title_shop">Pedagogia</span></div>
              <div class="price">
       <div class="cart-left">
        <p class="title">Camiseta Branca - Pedagogia</p>
        <div class="price1">
          <span class="actual">A partir de 5unid. R$25,00</span>
        </div>
      </div>
      <div class="cart-right"> </div>
      <div class="clear"></div>
     </div>
             </div>
             </a>
  </div>
  <div class="clear"></div>
</div>
</div>
