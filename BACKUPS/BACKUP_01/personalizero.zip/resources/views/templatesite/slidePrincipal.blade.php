<div id="fwslider">
    <div class="slider_container">
        <div class="slide">
            <!-- Slide image -->
                <img src="images/banner_site2.jpg" alt=""/>
            <!-- /Slide image -->
            <!-- Texts container -->
            <div class="slide_content">
                <div class="slide_content_wrap">
                    <!-- Text title -->
                    <h4 class="title">Camisetas Cacadêmicas</h4>
                    <!-- /Text title -->

                    <!-- Text description -->
                    <p class="description">A partir de 10 unid. R$30,00 <details open></details></p>
                    <!-- /Text description -->
                </div>
            </div>
             <!-- /Texts container -->
        </div>
        <!-- /Duplicate to create more slides -->
        <div class="slide">
            <img src="images/banner_site1.jpg" alt=""/>
            <div class="slide_content">
                <div class="slide_content_wrap">
                    <h4 class="title">Camisetas Baby Chá e Aniversários </h4>
                    <p class="description">Personalizamos sua festa!</p>
                </div>
            </div>
        </div>
        <!--/slide -->

        <!-- /Duplicate to create more slides -->
        <div class="slide">
            <img src="images/banner_site3.jpg" alt=""/>
            <div class="slide_content">
                <div class="slide_content_wrap">
                    <h4 class="title">Camisetas TERCEIRÃO </h4>
                    <p class="description">A Partir 10 unid. R$35,00</p>
                </div>
            </div>
        </div>
        <!--/slide -->
    </div>
    <div class="timers"></div>
    <div class="slidePrev"><span></span></div>
    <div class="slideNext"><span></span></div>
</div>
