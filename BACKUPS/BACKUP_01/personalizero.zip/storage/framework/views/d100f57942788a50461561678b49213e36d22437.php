
<!DOCTYPE HTML>
<html>
<head>
     <?php echo $__env->make('templatesite.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <!-- Topo do site

   // Fim topo site -->

  <!-- Menu -->
	   <?php echo $__env->make('templatesite.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- // Fim Menu -->


  <!-- start slider Principal -->
     <?php echo $__env->make('templatesite.slidePrincipal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!--/ FIM slider Principal -->


<!-- Conteúdo Principal -->

<!-- Lista de Produtos -->
    <div class="main">
    	<div class="wrap">
    		<div class="section group">

         <?php echo $__env->make('templatesite.produtosIndex', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- // Lista de Produtos -->

        <!-- Conteúdo Lateral Direito -->

        <!-- Anuncio Lateral Direito  -->
    		<?php echo $__env->make('templatesite.anuncio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- // Anuncio Lateral Direito -->


        <!-- Orçamento Rápido -->
    		<?php echo $__env->make('templatesite.orcamentoRapido', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- // Orçamento Rápido -->


        <!-- footer -->
        <?php echo $__env->make('templatesite.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- footer -->
</body>
</html>
