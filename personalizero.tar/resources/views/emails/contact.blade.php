<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <p><strong>Nome:: </strong>{!! $nome_cliente !!}</p>
    <p><strong>Email:: </strong>{!! $email !!}</p>
    <p><strong>Celular:: </strong>{!! $celular !!}</p>
    <p><strong>Assunto:: </strong>{!! $assunto !!}</p>
    <p><strong>Mensagem:: </strong>{!! $mensagem !!}</p>

  </body>
</html>
