@extends('templatesite.principal')

@section('title', 'Produto não encontrado!')

@section('content')
<div class="wrap">
  <h2 class="head">@yield('title')</h2>
<ul class="breadcrumb breadcrumb__t"><a class="home" href="#"></ul>
  <div class="content-top">


    <div class="col-lg-12">

              <h3>Nenhum produto encontrado com o nome solicitado, tente outro nome!!!</h3>
    </div>


  <div class="top-box">
</div>
</div>
</div>
  @endsection
