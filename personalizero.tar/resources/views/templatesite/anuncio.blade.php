<div class="rsidebar span_1_of_left">
  <div class="top-border"> </div>
   <div class="border">
         <link href="css/default.css" rel="stylesheet" type="text/css" media="all" />
         <link href="css/nivo-slider.css" rel="stylesheet" type="text/css" media="all" />
    <script src="js/jquery.nivo.slider.js"></script>
      <script type="text/javascript">
      $(window).load(function() {
          $('#slider').nivoSlider();
      });
      </script>
  <div class="slider-wrapper theme-default">
        <div id="slider" class="nivoSlider">
          <img src="images/anuncio1.jpg"  alt="" />
          <img src="images/anuncio2.jpg"  alt="" />
          <img src="images/anuncio3.jpg"  alt="" />
        </div>
       </div>
      
       </div>
     <div class="top-border"> </div>
