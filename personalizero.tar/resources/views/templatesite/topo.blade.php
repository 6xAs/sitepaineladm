<div class="header-top">
<div class="wrap">
   <div class="header-top-left">
        <div class="box">
           <select tabindex="4" class="dropdown">
         <option value="" class="label" value="">Linguagem</option>
         <option value="1">English</option>
         <option value="2">Portuges</option>
         <option value="3">Espanhol</option>
       </select>
         </div>
         <div class="box1">
             <select tabindex="4" class="dropdown">
         <option value="" class="label" value="">Currency :</option>
         <option value="1">$ Dollar</option>
         <option value="2">€ Euro</option>
       </select>
         </div>
         <div class="clear"></div>
    </div>
  <div class="cssmenu">
   <ul>

   </ul>
 </div>
 <div class="clear"></div>
</div>
</div>
